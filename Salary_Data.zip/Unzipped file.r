# Zip folder file path
zip_file_path <- "C:\\Users\\ifeol\\OneDrive\\Desktop\\NEXFORD\\ASSIGNMENTS\\Employee_Profile.zip"
output_directory <- "C:\\Users\\ifeol\\OneDrive\\Desktop\\NEXFORD\\ASSIGNMENTS\\Employee Profile"
# To unzip the file
unzip(zip_file_path, exdir = output_directory)

